# 외부 검토 근거

1. 한국환경정책학회 『환경정책』 투고규정: https://kepas.or.kr/homepage/custom/rule2
   - 국문 논문의 표·그림·사진 제목과 설명은 모두 한글로 작성.
   - 모든 표·그림 제목은 해당 항목 상단에 가운데 맞춤으로 배치.
   - 본문에서 표·그림을 인용할 때 <표 1>, <그림 1> 형식을 사용.
   - 수식에는 우측에 (1), (2) 등 일련번호 부여.
   - 원고는 A4 약 15매 내외, 최종 인쇄본 도표 포함 10쪽 이내 권장(초과 시 비용).
   - 국·영문 초록은 가능한 300단어 이내, 주제어 5개 이내.
   - 참고문헌에는 본문 인용 문헌만 포함하고 모든 본문 인용 문헌을 포함.

2. NIST WUI Definitions: https://www.nist.gov/el/fire/resources/hazard-mitigation-methodology-hmm/why-implement-hmm-your-community/wui-definitions
   - Interface는 고밀도 개발지가 미개발 야생식생과 인접한 구역.
   - Intermix는 저밀도 주택이 야생식생과 혼재한 구역.
   - 주택밀도와 식생피복 기준이 핵심이며 단순 거리 고리만으로 Interface/Intermix를 구분하지 않음.

3. Radeloff et al. (2018), PNAS: https://www.pnas.org/doi/10.1073/pnas.1718850115
   - Intermix WUI: 주택과 야생식생이 직접 혼재하며 주택밀도와 식생비율 기준 사용.
   - Interface WUI: 정주지가 대규모 고밀도 식생지역에 인접하며 주택밀도·식생피복·2.4km 이내 거리 조건 사용.
   - 원고의 Interface 0–100m, Intermix 100–300m, Influence 300–500m와 정의가 다름.

4. Schug et al. (2023), Nature: https://www.nature.com/articles/s41586-023-06320-0
   - 글로벌 WUI는 건물과 야생식생이 만나거나 혼재하는 곳으로 정의하며, intermix와 interface를 건물·식생의 혼재/인접 관계로 구분.

5. Esri ArcGIS Pro Data Classification Methods: https://doc.esri.com/en/arcgis-pro/latest/help/mapping/layer-properties/data-classification-methods.html
   - Natural Breaks는 데이터 고유 분포에 따라 경계가 정해지는 데이터 특이적 분류.
   - 서로 다른 원자료로 만든 여러 지도를 비교하는 데 개별 Natural Breaks는 부적합하다고 명시.
   - 본 원고가 공통 경계를 적용한 점은 비교가능성을 높이지만, 경계 산출에 어떤 값들을 풀링했는지 명확히 밝혀야 함.

6. CDC Jenks 설명: https://www.cdc.gov/nchs/hus/sources-definitions/jenks-natural-breaks.htm
   - Jenks는 집단 내 분산을 최소화하고 집단 간 분산을 최대화하는 분류법.
